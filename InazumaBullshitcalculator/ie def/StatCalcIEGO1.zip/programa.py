#!/usr/bin/env python3
"""Compatibility launcher for the renamed StatCalcIEGO1 application."""
import StatCalcIEGO1 as _app

# Preserve imports used by existing scripts, including private helpers.
globals().update({k: v for k, v in vars(_app).items() if not k.startswith("__")})

if __name__ == "__main__":
    _app.main()
